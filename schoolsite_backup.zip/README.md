React + Node website ver0.1
to start front end use
**npm run dev -- --host**
to start back end use
**npm start**
to start ai back end use
**uvicorn server:app --host 0.0.0.0 --port 8067**
